package com.nyandori.examsandquizpractice

import android.os.Build
import android.os.Bundle
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.recyclerview.widget.LinearLayoutManager
import com.nyandori.examsandquizpractice.databinding.ActivityQuestionsDisplayBinding
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.select.Elements
import java.io.IOException


class QuestionsDisplayActivity : AppCompatActivity() {
    lateinit var binding: ActivityQuestionsDisplayBinding
    companion object{
        var link: String = ""

    }
    lateinit var adapter: AllSolutionsAdapter
    lateinit var quizModelList: MutableList<QuizModel>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuestionsDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val policy = ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        quizModelList = mutableListOf()
        getData(link)

    }

    private fun setRecyclerView(){
        binding.progressBar.visibility = View.GONE
        adapter = AllSolutionsAdapter(quizModelList)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    private fun getData(url:String){
        try {
            // Fetch the HTML content
            val doc: Document =
                Jsoup.connect(url)
                    .get()

            // Select the articles containing questions
            val articles: Elements = doc.select("article.question.single-question.question-type-normal:not(.center)")
            val articlesWithoutLast = if (articles.size > 1) articles.subList(0, articles.size - 1) else articles
            val articleList = mutableListOf<Map<String, Any>>()

            Log.d("Number of Elements", "There are ${articlesWithoutLast.size} in the page ")
            for (article in articlesWithoutLast) {
                // Extract the question number
                val questionNumber: String = article.select("h2 div.question-number").text().replace(".", "")

                // Extract the question
                val question: String = article.select("div.question-main").text()

                // Extract the options
                val options: Elements = article.select("div.form-inputs p")
                val choices = mutableMapOf<String, String>()
                for (option in options) {
                    val label: Element? = option.selectFirst("label")
                    if (label != null) {
                        val labelText: String = label.text().replace(".", "")
                        val choiceText: String = option.select("label[for=${option.selectFirst("input")?.id()}]").text()
                        choices[labelText] = choiceText
                    }
                }
                val A = choices["A"].toString()
                val B = choices["B"].toString()
                val C = choices["C"].toString()
                val D= choices["D"].toString()

                val answers= Choices(A, B, C, D)

                // Extract the correct option
                val correctOption: String = article.select("strong").text()

                // Extract the solution and explanation
                val solutionContainer: Element? = article.selectFirst("div.answer_container")
                val solutionText: String = solutionContainer?.select("div")?.get(2)?.text() ?: ""

               val solutionDivs: Elements = article.select("span.color")
                val solutionDiv: Element? = if (solutionDivs.size == 2) {
                    solutionDivs[1].parent().parent()
                } else {
                    solutionDivs[0]
                }
                val detailedSolutionText: String = solutionDiv?.text()?.replace("\n", "\n") ?: ""
                println(detailedSolutionText)
                val row = mapOf(
                    "questionNumber" to questionNumber,
                    "question" to question,
                    "choices" to choices,
                    "correctOption" to correctOption,
                    "solution" to detailedSolutionText
                )
                val quizModel : QuizModel = QuizModel(questionNumber,
                    question,
                    answers,
                    correctOption,
                    detailedSolutionText

                    )
                quizModelList.add(quizModel)
                // Add the map to the list
                articleList.add(row)
            }
            setRecyclerView()
            println(articleList)
        }
        catch (e:IOException){
            e.printStackTrace()
        }
    }
}